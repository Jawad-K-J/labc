#include<stdio.h>
#define pi 3.14
void main ( )
{
int rad = 6;
float per, area;
area = pi*(rad*rad);
printf("area = %f \n",area);
per = 2*(pi*rad);
printf("perimeter = %f \n",per);
}
