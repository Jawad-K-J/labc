#include<stdio.h>
int fact(int);
void main()
{
int num;
printf("enter the number:");
scanf("%d",&num);
int F=fact(num);
printf("factorial is %d",F);
}int fact (int n)
{
if((n==0)||(n==1))
{return 1;
}
else
{
return (n*fact(n-1));}
}
