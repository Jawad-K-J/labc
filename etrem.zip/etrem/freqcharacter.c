#include<stdio.h>

#include<string.h>
void main()
{char s[25];
int i,count=0,j,n;
printf("\nenter the string:");
scanf("%s",s);
n=strlen(s);
for(i=0;i<n;i++)
{count=1;
if(s[i])
{ for(j=i+1;j<n;j++)
{ if(s[i]==s[j])
{
count++;
s[j]='\0';
}} printf(" %c occurs= %d \n",s[i],count);
}}

}
