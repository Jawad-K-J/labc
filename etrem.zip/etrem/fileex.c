#include<stdio.h>
void main()
{
FILE *fp;
int rollno,phno;
char name[20];

fp=fopen("student.txt","w");
if(fp==NULL)
{
printf("The file doesn't exist");
}
else
{
printf("Enter the student roll no:");
scanf("%d",&rollno);
printf("ENter the name:");
scanf("%s",name);
printf("Enter the student phone no:");
scanf("%d",&phno);
fprintf(fp,"%d",rollno);
fprintf(fp,"\t");
fprintf(fp,"%s",name);
fprintf(fp,"\t");
fprintf(fp,"%d",phno);
fprintf(fp,"\n");
fclose(fp);
fp=fopen("student.txt","r");
printf("The student details:");
while(fscanf(fp,"%d\t %s\t %d\n",&rollno,name,&phno)!=EOF)
{
printf("%d \t %s\t %d",rollno,name,phno);
}
}
 fclose(fp);
}

