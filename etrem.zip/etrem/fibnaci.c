#include<stdio.h>
int fib(int);
int main()
{int n, m=0, i;
printf("enter the limit:");
scanf("%d",&n);
printf("Fibonacci series are:");
for(i=0;i<=n;i++)
{ 
printf("%d",fib(m));
m++; 
}
return 0; 
} 
int fib(int n)
{ if (n==0||n==1)
{ return n;
} else 
{ return (fib(n -1) +( n -2)) ;
}
}
