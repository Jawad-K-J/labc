#include<stdio.h>
void main()
{
 int a =1;
char b = 'G';
double c = 3.14;
printf("intiger is %d \n",a);
printf("character is %c \n",b);
printf("double is %f \n",c);
printf("size of integer is %lu \n",sizeof(a));
printf("size of character is %lu \n",sizeof(b));
printf("size of double is %lu \n", sizeof(c));

}
